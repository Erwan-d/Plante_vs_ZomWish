<template>
  <!-- Zone où Phaser affichera le jeu -->
  <div id="game-container"
       @click="handleClick"
       class="game-zone">
  </div>
</template>

<script>
import Phaser from "phaser";
import GameScene from "../phaser/GameScene.js";

export default {
  data() {
    return {
      game: null,   // Instance Phaser
      scene: null   // Référence directe à la scène Phaser
    };
  },

  mounted() {
    // Création du jeu Phaser dans le composant Vue
    this.game = new Phaser.Game({
      type: Phaser.AUTO,
      width: 500,   // largeur totale de la grille (5 × 100)
      height: 500,  // hauteur totale
      parent: "game-container", // Phaser se dessine dans ce <div>
      backgroundColor: "#000000",
      scene: [GameScene]
    });

    // Permet de récupérer la scène lorsqu'elle est prête
    this.game.events.on("ready", () => {
      this.scene = this.game.scene.keys["GameScene"];
    });

    // Sécurité : on force la récupération après un court délai
    setTimeout(() => {
      this.scene = this.game.scene.keys["GameScene"];
    }, 200);
  },

  methods: {

    // Détecte où l'utilisateur a cliqué et convertit en cellule de grille
    handleClick(e) {
      const rect = e.target.getBoundingClientRect();

      // Coordonnées du clic dans la zone du jeu
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Convertit les pixels en positions de grille
      const col = Math.floor(x / 100);
      const row = Math.floor(y / 100);

      // Appelle la fonction Phaser pour placer une plante
      if (this.scene) {
        this.scene.placePlant(row, col);
      }
    }
  }
};
</script>

<style>
/* Cadre du jeu */
.game-zone {
  width: 500px;
  height: 500px;
  margin: auto;
  border: 2px solid white;
}
</style>
