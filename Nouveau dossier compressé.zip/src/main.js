import { createApp } from 'vue';
import App from './App.vue';

// Démarre l'application Vue et l'attache à la page HTML
createApp(App).mount('#app');
