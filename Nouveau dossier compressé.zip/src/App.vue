<template>
  <!-- On affiche notre composant principal du jeu -->
  <Game />
</template>

<script>
import Game from "./components/Game.vue";

export default {
  components: {
    Game
  }
};
</script>

<style>
/* Style global */
body {
  background: #222;
  color: white;
  margin: 0;
}
</style>
