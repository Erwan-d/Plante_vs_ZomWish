// ==============================
//  GAME.JS – VERSION CORRIGÉE
// ==============================

class GameScene extends Phaser.Scene {
    constructor() {
        super("GameScene");
    }

    preload() {
        this.load.image("tournesol", "style/images/tournesol.png");
        this.load.image("pisto", "style/images/pistopoix.png");
    }

    create() {

        // Dimensions de la grille
        this.rows = 5;
        this.cols = 5;
        this.cellSize = 150;

        const gridSizePx = this.cellSize * this.rows;

        // Position centrée
        const startX = (this.game.config.width - gridSizePx) / 2;
        const startY = (this.game.config.height - gridSizePx) / 2;

        this.grid = [];

        // ==============================
        //   GRILLE 5×5 VISIBLE + ACTIVE
        // ==============================
        for (let r = 0; r < this.rows; r++) {
            this.grid[r] = [];

            for (let c = 0; c < this.cols; c++) {

                const x = startX + c * this.cellSize + this.cellSize / 2;
                const y = startY + r * this.cellSize + this.cellSize / 2;

                // Case visible : rectangle blanc avec bord
                const cell = this.add.rectangle(
                    x, y,
                    this.cellSize - 2, this.cellSize - 2,
                    0xffffff,
                    1                // OPACITÉ PLUS FORTE → maintenant visible
                )
                .setStrokeStyle(3, 0x000000) // Bord noir visible
                .setInteractive({ dropZone: true });

                this.grid[r][c] = { rect: cell, plant: null };
            }
        }

        // ==============================
        //   PALETTE DE PLANTES
        // ==============================
        this.createPalette();

        // ==============================
        //   DRAG & DROP GLOBAL
        // ==============================

        // Pendant le drag
        this.input.on("drag", (pointer, gameObject, dragX, dragY) => {
            gameObject.x = dragX;
            gameObject.y = dragY;
        });

        // Quand on lâche sur une dropZone
        this.input.on("drop", (pointer, gameObject, dropZone) => {
            this.placePlant(gameObject, dropZone);
        });

        // Quand on lâche hors zone valide
        this.input.on("dragend", (pointer, gameObject, dropped) => {
            if (!dropped) {
                gameObject.x = gameObject.startX;
                gameObject.y = gameObject.startY;
            }
        });
    }

    // ==============================
    //  PALETTE PHASER (DRAG PERMIS)
    // ==============================
    createPalette() {
        const plants = [
            { key: "tournesol", y: 170 },
            { key: "pisto", y: 330 }
        ];

        plants.forEach(p => {
            const sprite = this.add.image(120, p.y, p.key)
                .setScale(0.8)
                .setInteractive();

            // Position d’origine = pour retour si raté
            sprite.startX = sprite.x;
            sprite.startY = sprite.y;

            // —— ACTIVATION DRAG ——  
            this.input.setDraggable(sprite);
        });
    }

    // ============================
    //  POSE D’UNE PLANTE
    // ============================
    placePlant(gameObject, dropZone) {

        for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {

                if (this.grid[r][c].rect === dropZone) {

                    // Case déjà occupée → retour palette
                    if (this.grid[r][c].plant) {
                        gameObject.x = gameObject.startX;
                        gameObject.y = gameObject.startY;
                        return;
                    }

                    // Positionne dans la case
                    gameObject.x = dropZone.x;
                    gameObject.y = dropZone.y;

                    // Bloque le redrag (optionnel)
                    this.input.setDraggable(gameObject, false);

                    // Sauvegarde
                    this.grid[r][c].plant = gameObject;
                    return;
                }
            }
        }
    }
}

// =======================
//  CONFIG PHASER
// =======================
const config = {
    type: Phaser.AUTO,
    width: 1200,
    height: 700,
    parent: "game-container",
    backgroundColor: "#113311",
    scene: [GameScene]
};

new Phaser.Game(config);


